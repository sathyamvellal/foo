package mybean;

public class MyBean {
	private String user;
	private String pass;

	public MyBean() {
	}

	public String getUser() {
		return user;
	}

	public String getPass() {
		return pass;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public boolean checkUser() {
		if (this.user.equals("one") && this.pass.equals("passone")) {
			return true;
		}
		return false;
	}
}
