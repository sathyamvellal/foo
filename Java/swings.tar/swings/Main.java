import javax.swing.*;

public class Main {
	public static void main(String[] args) {
		try {
			SwingUtilities.invokeAndWait(new Runnable() {
				public void run() {
					new Application();
				}
			});
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
