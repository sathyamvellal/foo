import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class MyServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter w = res.getWriter();
		String txtA = req.getParameter("txtA");
		String txtB = req.getParameter("txtB");
		Integer a =	Integer.parseInt(txtA);
		Integer b = Integer.parseInt(txtB);
		w.println("<html><body>" + (a + b) + "</body></html>");
	}
}
