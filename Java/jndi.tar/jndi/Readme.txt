

Step 1: compile Lookup.java in JGrasp


Step 2 : on JGrasp, select Build->Run Arguments
   


Step 3 : type any "file name" which is present directly in root directory ex:any file under c:\,d:\ etc...
in Argument field of JGrasp
    
Step 4: Click Run 

Ex output : test.txt is bound to: c:\test.txt
