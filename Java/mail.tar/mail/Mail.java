import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.mail.*;
import javax.mail.internet.*;

public class Mail extends HttpServlet {
    public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException, RuntimeException {
	String user = req.getParameter("user");
	String pass = req.getParameter("pass");
	String to = req.getParameter("to");
	String sub = req.getParameter("subject");
	String msg = req.getParameter("message");
	
	final String username = user;
	final String password = pass;
	boolean successFlag = false;
		
	Properties p = System.getProperties();
	p.put("mail.smtp.auth", "true");
	p.put("mail.smtp.starttls.enable", "true");
	p.put("mail.smtp.host", "smtp.gmail.com");
	p.put("mail.smtp.port", "587");

	Session session = Session.getDefaultInstance(p, new javax.mail.Authenticator() {
	    protected PasswordAuthentication getPasswordAuthentication(){
		return new PasswordAuthentication(username, password);
	    }
	});
	
	try{
	    Message message = new MimeMessage(session);
	    message.setFrom(new InternetAddress(user));
	    message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
	    message.setSubject(sub);
	    message.setText(msg);
	    Transport.send(message);
	    successFlag = true;
	} catch (MessagingException e) {
	    successFlag = false;
	    throw new RuntimeException(e);
	}

	if (successFlag) {
	    res.getWriter().print("<html><body>Check your mail!</body></html>");
	} else {
	    res.getWriter().print("<html><body>Mail Failed!</body></html>");
	}
    }
}
