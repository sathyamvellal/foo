import java.util.*;

public class Main {
	public static void main(String[] args) {
		Printer p = new Printer();
		Thread t1 = new Thread(new Foo(1, 30, p));
		Thread t2 = new Thread(new Foo(1, 40, p));
		Thread t3 = new Thread(new Foo(10, 25, p));
		t1.start();
		t2.start();
		t3.start();
	}
}

class Printer {
	//void print(String msg) throws InterruptedException {
	synchronized void print(String msg) throws InterruptedException {
		for (int i = 0; i < msg.length(); ++i) {
			System.out.print(msg.charAt(i));
			Thread.sleep(50);
		}
		System.out.println();
	}
}

class Foo implements Runnable {
	Printer p;
	int start;
	int end;

	Foo(int start, int end, Printer p) {
		this.start = start;
		this.end = end;
		this.p = p;
	}

	public void run() {
		try {
			String msg = new String("");
			for (int i = start; i < end; ++i) {
				msg += i + " ";
				Thread.sleep(100);
			}
			p.print(msg);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
