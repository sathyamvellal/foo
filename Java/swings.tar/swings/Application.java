import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

@SuppressWarnings("serial")
public class Application extends JFrame {
	JButton jb7 = new JButton("7");
	JButton jb8 = new JButton("8");
	JButton jb9 = new JButton("9");
	JButton jb4 = new JButton("4");
	JButton jb5 = new JButton("5");
	JButton jb6 = new JButton("6");
	JButton jb1 = new JButton("1");
	JButton jb2 = new JButton("2");
	JButton jb3 = new JButton("3");
	JButton jb0 = new JButton("0");
	JButton jbsign = new JButton("+/-");
	JButton jbdot = new JButton(".");
	JButton jbdel = new JButton("del");
	JButton jbac = new JButton("AC");
	JToggleButton jbadd = new JToggleButton("+");
	JToggleButton jbsub = new JToggleButton("-");
	JToggleButton jbmul = new JToggleButton("*");
	JToggleButton jbdiv = new JToggleButton("/");
	JButton jbeq = new JButton("=");
	JTextField jtext = new JTextField();
	
	Double op1 = new Double(0);
	Double op2 = new Double(0);
	Double res = new Double(0);
	
	Application() {
		setSize(370, 285);
		setLayout(null);
		setVisible(true);

		jtext.setBounds(10, 10, 340, 25);
		jtext.setFont(new Font("Consolas", Font.PLAIN, 20));
		jtext.setEditable(false);
		add(jtext);

		jb7.setBounds(10, 60, 60, 40);
		jb8.setBounds(80, 60, 60, 40);
		jb9.setBounds(150, 60, 60, 40);
		jb4.setBounds(10, 110, 60, 40);
		jb5.setBounds(80, 110, 60, 40);
		jb6.setBounds(150, 110, 60, 40);
		jb1.setBounds(10, 160, 60, 40);
		jb2.setBounds(80, 160, 60, 40);
		jb3.setBounds(150, 160, 60, 40);
		jb0.setBounds(10, 210, 60, 40);
		jbsign.setBounds(80, 210, 60, 40);
		jbdot.setBounds(150, 210, 60, 40);
		jbdel.setBounds(220, 60, 60, 40);
		jbac.setBounds(290, 60, 60, 40);
		jbadd.setBounds(220, 110, 60, 40);
		jbsub.setBounds(290, 110, 60, 40);
		jbmul.setBounds(220, 160, 60, 40);
		jbdiv.setBounds(290, 160, 60, 40);
		jbeq.setBounds(220, 210, 130, 40);
		add(jb7);
		add(jb8);
		add(jb9);
		add(jb4);
		add(jb5);
		add(jb6);
		add(jb1);
		add(jb2);
		add(jb3);
		add(jb0);
		add(jbsign);
		add(jbdot);
		add(jbdel);
		add(jbac);
		add(jbadd);
		add(jbsub);
		add(jbmul);
		add(jbdiv);
		add(jbeq);

		jb7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				jtext.setText(jtext.getText() + '7');
			}
		});
		jb8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				jtext.setText(jtext.getText() + '8');
			}
		});
		jb9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				jtext.setText(jtext.getText() + '9');
			}
		});
		jb4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				jtext.setText(jtext.getText() + '4');
			}
		});
		jb5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				jtext.setText(jtext.getText() + '5');
			}
		});
		jb6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				jtext.setText(jtext.getText() + '6');
			}
		});
		jb1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				jtext.setText(jtext.getText() + '1');
			}
		});
		jb2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				jtext.setText(jtext.getText() + '2');
			}
		});
		jb3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				jtext.setText(jtext.getText() + '3');
			}
		});
		jb0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				jtext.setText(jtext.getText() + '0');
			}
		});
		jbsign.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				if (jtext.getText().charAt(0) == '-') {
					jtext.setText(jtext.getText().substring(1));
				} else {
					jtext.setText('-' + jtext.getText().substring(0));
				}
				
			}
		});
		jbdot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				jtext.setText(jtext.getText() + '.');
			}
		});
		jbdel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				if (jtext.getText().length() > 0)
					jtext.setText(jtext.getText().substring(0, jtext.getText().length()-1));
			}
		});
		jbac.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				jtext.setText("");
			}
		});
		jbadd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				jbsub.setSelected(false);
				jbmul.setSelected(false);
				jbdiv.setSelected(false);
				
				if (jbadd.isSelected() == true) {
					op1 = Double.parseDouble(jtext.getText());
					jtext.setText("");
				}
			}
		});
		jbsub.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				jbadd.setSelected(false);
				jbmul.setSelected(false);
				jbdiv.setSelected(false);
				
				if (jbsub.isSelected() == true) {
					op1 = Double.parseDouble(jtext.getText());
					jtext.setText("");
				}
			}
		});
		jbmul.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				jbadd.setSelected(false);
				jbsub.setSelected(false);
				jbdiv.setSelected(false);
				
				if (jbmul.isSelected() == true) {
					op1 = Double.parseDouble(jtext.getText());
					jtext.setText("");
				}
			}
		});
		jbdiv.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				jbadd.setSelected(false);
				jbsub.setSelected(false);
				jbmul.setSelected(false);
				
				if (jbdiv.isSelected() == true) {
					op1 = Double.parseDouble(jtext.getText());
					jtext.setText("");
				}
			}
		});
		jbeq.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				op2 = Double.parseDouble(jtext.getText());
				
				if (jbadd.isSelected() == true) {
					res = op1 + op2;
				} else if (jbsub.isSelected() == true) {
					res = op1 - op2;
				} else if (jbmul.isSelected() == true) {
					res = op1 * op2;
				} else if (jbdiv.isSelected() == true) {
					res = op1 / op2;
				}
				jtext.setText("" + res);
								
				jbadd.setSelected(false);
				jbsub.setSelected(false);
				jbmul.setSelected(false);
				jbdiv.setSelected(false);
			}
		});
	}
}
