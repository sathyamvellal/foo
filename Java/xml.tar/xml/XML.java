import java.io.*;
import java.util.*;
import javax.xml.parsers.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;

public class XML extends DefaultHandler {
	static List<String> emps = new ArrayList<String>();
	public static StringBuffer buffer = new StringBuffer();

	public static void main(String[] args) {
		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser parser = factory.newSAXParser();
			File file = new File("test.xml");

			parser.parse(file, new XML());
			System.out.println(buffer);
			System.out.println("the no. of emps are :: " + emps.size());
			for (int i = 0; i < emps.size(); ++i) {
				System.out.println("EMP" + i + "n" + emps.get(i));
			}
		} catch(IOException e) {
			e.printStackTrace();
		} catch(ParserConfigurationException e) {
			e.printStackTrace();
		} catch(SAXException e) {
			System.out.println("XML is not well formed!");
		}
	}

	public void startElement(String uri, String localName, String qName, Attributes attr) throws SAXException {
		buffer.append("<");
		System.out.println("<" + qName + ">");
		buffer.append(qName);
		buffer.append(">");
	}

	public void endElement(String uri, String localName, String qName, Attributes attr) throws SAXException {
		buffer.append("</");
		System.out.println("</" + qName + ">");
		buffer.append(qName);
		buffer.append(">");
		if (qName.equalsIgnoreCase("employee")) {
			emps.add(buffer);
		}
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		System.out.println(new String(ch, start, length));
		buffer.append(new String(ch, start, length).replaceAll("&", "&amp;").trim());
	}
}
