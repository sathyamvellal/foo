import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Application extends JApplet {
	public void init() {
		try {
			SwingUtilities.invokeAndWait(new Runnable() {
				public void run() {
					makeGUI();
				}
			});
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	private void makeGUI() {
		JTabbedPane jtp = new JTabbedPane();
		jtp.add(new PanelOne(), "Number");
		jtp.add(new PanelTwo(), "Counter");
		add(jtp);
	}
}

class PanelOne extends JPanel {
	JTextField jtext1;
	JTextField jtext2;
	JButton jtb;
	JLabel jlabel;

	PanelOne() {
		setLayout(new FlowLayout());
		jtext1 = new JTextField(15);
		jtext2 = new JTextField(15);
		jtb = new JButton("Click");
		jlabel = new JLabel("");
		add(jtext1);
		add(jtext2);
		add(jtb);
		add(jlabel);

		jtb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				jlabel.setText(jtext1.getText() + jtext2.getText());
			}
		});
	}
}

class PanelTwo extends JPanel {
	JTextField jtxt;
	JButton jstart;
	JButton jstop;
	Thread t;
	boolean running = false;

	PanelTwo() {
		setLayout(new FlowLayout());
		jtxt = new JTextField(15);
		jstart = new JButton("Start");
		jstop = new JButton("Stop");
		jtxt.setText("0");
		
		add(jtxt);
		add(jstart);
		add(jstop);
		
		jstart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				t = new Thread(new Runnable() {
					public void run() {
						running = true;
						while (running) {
							try {
								jtxt.setText(Integer.parseInt(jtxt.getText())
										+ 1 + "");
								Thread.sleep(1000);
							} catch (Exception e) {
								System.out.println(e);
							}
						}
					}
				});
				t.start();
			}
		});
		
		jstop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				running = false;
			}
		});
	}
}